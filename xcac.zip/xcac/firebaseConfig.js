import { initializeApp } from 'firebase/app';
import { initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';
//Firebase config 
const firebaseConfig = {
    apiKey: "AIzaSyCRAb6KCCcc12llaSb4cw2NuMzMbmkAWk4",
    authDomain: "xcac-8976c.firebaseapp.com",
    projectId: "xcac-8976c",
    storageBucket: "xcac-8976c.appspot.com",
    messagingSenderId: "278556932110",
    appId: "1:278556932110:web:8c8d7f5b782f3a36bc245f"
  };

const app = initializeApp(firebaseConfig);
const db = getFirestore(app); // read/write data 
const auth = initializeAuth(app, {
    persistence: getReactNativePersistence(ReactNativeAsyncStorage)
  });
export {db,auth}
