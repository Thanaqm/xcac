import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList, DrawerItem } from '@react-navigation/drawer';
import { Alert, StyleSheet } from 'react-native';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { auth } from './firebaseConfig';
import { LinearGradient } from 'expo-linear-gradient';
import LoginScreen from './components/login';
import SignupScreen from './components/signup';
import CurrencyConverter from './components/currencyConverter';
import Profile from './components/profile';
import AboutUs from './components/aboutUs';
import LocationFinder from './components/locationFinder';

const Drawer = createDrawerNavigator();

export default function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    onAuthStateChanged(auth, (currentUser) => setUser(currentUser));
  }, []);

  return (
    <LinearGradient
      colors={['#a0e5f0', '#f0d0d7']}
      style={styles.background}
    >
      <NavigationContainer>
        <Drawer.Navigator
          initialRouteName={user ? "CurrencyConverter" : "Login"}
          drawerContent={(props) => <CustomDrawerContent {...props} />}
        >
          {user ? (
            <>
           
              <Drawer.Screen name="CurrencyConverter" component={CurrencyConverter} />
              <Drawer.Screen name="Profile" component={Profile} />
              <Drawer.Screen name="AboutUs" component={AboutUs} />
              <Drawer.Screen name="LocationFinder" component={LocationFinder} />
            </>
          ) : (
            <>
              <Drawer.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
              <Drawer.Screen name="Signup" component={SignupScreen} options={{ title: 'Sign Up' }} />
            </>
          )}
        </Drawer.Navigator>
      </NavigationContainer>
    </LinearGradient>
  );
}
//Logout function
function CustomDrawerContent(props) {
  const handleLogout = () => {
    Alert.alert("Are you sure?", "Do you want to logout?", [
      { text: "Cancel", style: "cancel" },
      { text: "Logout", onPress: () => signOut(auth).then(() => props.navigation.navigate("Login")) }
    ]);
  };

  return (
    <LinearGradient colors={['#a0e5f0', '#f0d0d7']} style={styles.background}>
    <DrawerContentScrollView {...props}>
      <DrawerItemList {...props} />
      <DrawerItem
        label="Logout"
        onPress={handleLogout}
        style={{ marginTop: 'auto', borderTopWidth: 1, borderTopColor: '#ccc' }}
      />
    </DrawerContentScrollView></LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
});
