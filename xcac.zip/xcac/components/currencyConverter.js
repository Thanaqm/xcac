import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, Button, Modal, TouchableOpacity, FlatList, ActivityIndicator, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import XCAC_icon from '../assets/XCAC_icon.jpg';

const CurrencyConverter = () => {
  const [currencies, setCurrencies] = useState([]);
  const [baseCurrency, setBaseCurrency] = useState('SEK');
  const [targetCurrency, setTargetCurrency] = useState('EUR');
  const [rate, setRate] = useState(null);
  const [amount, setAmount] = useState('1');
  const [isLoading, setIsLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedCurrencyType, setSelectedCurrencyType] = useState('base');

  useEffect(() => {
    fetch('https://api.frankfurter.app/currencies')
      .then(response => response.json())
      .then(data => setCurrencies(Object.keys(data).map(code => ({ code, name: data[code] }))))
      .catch(() => setError('Error fetching currencies'))
      .finally(() => setIsLoading(false));
  }, []);

  useEffect(() => {
    if (baseCurrency && targetCurrency) {
      fetch(`https://api.frankfurter.app/latest?from=${baseCurrency}&to=${targetCurrency}`)
        .then(response => response.json())
        .then(data => setRate(data.rates[targetCurrency]))
        .finally(() => setIsLoading(false));
    }
  }, [baseCurrency, targetCurrency]);

  const handleCurrencySelect = currency => {
    selectedCurrencyType === 'base' ? setBaseCurrency(currency.code) : setTargetCurrency(currency.code);
    setModalVisible(false);
  };

  return (
    <LinearGradient colors={['#a0e5f0', '#f0d0d7']} style={styles.background}>
      <View style={styles.container}>
        <Image source={XCAC_icon} style={styles.image} />
        <Text style={styles.heading}>Currency Converter</Text>
        <Text style={styles.description}>Convert between currencies with real-time rates.</Text>

        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={amount}
          onChangeText={value => setAmount(value)}
          placeholder={`Amount in ${baseCurrency}`}
        />

        <TouchableOpacity style={styles.button} onPress={() => { setSelectedCurrencyType('base'); setModalVisible(true); }}>
          <Text style={styles.buttonText}>Select Base Currency: {baseCurrency}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.button} onPress={() => { setSelectedCurrencyType('target'); setModalVisible(true); }}>
          <Text style={styles.buttonText}>Select Target Currency: {targetCurrency}</Text>
        </TouchableOpacity>

        {isLoading && <ActivityIndicator size="large" color="#0000ff" />}
        {rate && amount > 0 && (
          <Text style={styles.result}>{amount} {baseCurrency} = {(rate * parseFloat(amount)).toFixed(2)} {targetCurrency}</Text>
        )}

        <Modal animationType="slide" transparent visible={modalVisible}>
          <View style={styles.modalView}>
            <FlatList
              data={currencies}
              keyExtractor={item => item.code}
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.modalItem} onPress={() => handleCurrencySelect(item)}>
                  <Text style={styles.modalText}>{item.code} - {item.name}</Text>
                </TouchableOpacity>
              )}
            />
            <Button title="Close" onPress={() => setModalVisible(false)} />
          </View>
        </Modal>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'transparent', 
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 20,
    borderRadius: 10,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    color: '#555',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
    width: '100%',
    backgroundColor: '#fff', 
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    marginVertical: 10,
    borderRadius: 5,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  result: {
    marginTop: 20,
    fontSize: 20,
    textAlign: 'center',
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    width: '100%',
  },
  modalText: {
    fontSize: 16,
  },
});

export default CurrencyConverter;
