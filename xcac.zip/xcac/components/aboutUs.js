import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import bank_counter from '../assets/bank_counter.jpg';

export default function AboutUs() {
  return (
    <LinearGradient colors={['#a0e5f0', '#f0d0d7']} style={styles.background}>
      <View style={styles.container}>
        <Image 
          source={bank_counter} 
          style={styles.image} 
        />
        <Text style={styles.heading}>Our Values</Text>
        <Text style={styles.text}>
          At XCAC, our values center around reliability and transparency. 
          We strive to simplify currency conversion, making it easy and accessible.
          Integrity and reliability drive every interaction, as we build a trustworthy platform for every user.
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'transparent', 
  },
  image: {
    width: 150,
    height: 150,
    marginBottom: 20,
    borderRadius: 10,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  text: {
    fontSize: 16,
    textAlign: 'center',
    color: '#555',
    paddingHorizontal: 10,
  },
});
