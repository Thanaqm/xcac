import React from 'react';
import { View, Text, Button, Alert, StyleSheet, Image } from 'react-native';
import { auth, sendPasswordResetEmail } from '../firebaseConfig';
import { LinearGradient } from 'expo-linear-gradient';
import XCAC_icon from '../assets/XCAC_icon.jpg';

export default function Profile() {
  const email = auth.currentUser ? auth.currentUser.email : ''; 

  const handleResetPassword = () => {
    if (!auth.currentUser) {
      Alert.alert('Error', 'No user is currently logged in.');
      return;
    }

    sendPasswordResetEmail(auth, email)
      .then(() => {
        Alert.alert('Password Reset', 'A password reset has been sent to your email address.');
      })
  };

  return (
    <LinearGradient colors={['#a0e5f0', '#f0d0d7']} style={styles.background}>
      <View style={styles.container}>
        <Image source={XCAC_icon} style={styles.image} />
        <Text style={styles.title}>Your Profile</Text>
        <Text style={styles.label}>Email:</Text>
        <Text style={styles.info}>{email || "No user logged in"}</Text>

        {auth.currentUser && <Button title="Reset Password" onPress={handleResetPassword} />}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent', 
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 20,
    borderRadius: 10,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  label: {
    fontSize: 18,
    marginBottom: 5,
    color: '#333',
  },
  info: {
    fontSize: 16,
    color: 'gray',
    marginBottom: 20,
  },
});
