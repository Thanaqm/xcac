import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text, Image } from 'react-native';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebaseConfig';
import { LinearGradient } from 'expo-linear-gradient';
import XCAC_icon from '../assets/XCAC_icon.jpg';

export default function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigation.navigate('CurrencyConverter'); 
    } catch (error) {
      setError('Invalid login credentials. Please try again.');
    }
  };

  return (
    <LinearGradient colors={['#a0e5f0', '#f0d0d7']} style={styles.background}>
      <View style={styles.container}>
        <Image source={XCAC_icon} style={styles.image} />
        <Text style={styles.heading}>Welcome to XCAC</Text>
        <Text style={styles.text}>Sign in to access smooth currency conversion</Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <Button title="Login" onPress={handleLogin} />
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        <Text style={styles.link} onPress={() => navigation.navigate('Signup')}>
          Don't have an account? Sign Up
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 60,
    backgroundColor: 'transparent', 
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 20,
    borderRadius: 10,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  text: {
    fontSize: 16,
    textAlign: 'center',
    color: '#555',
    paddingHorizontal: 10,
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
    width: '100%',
    backgroundColor: '#fff', 
    borderRadius: 5,
  },
  errorText: {
    color: 'red',
    marginTop: 10,
  },
  link: {
    color: 'blue',
    marginTop: 15,
  },
});
