import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import axios from 'axios';

export default function LocationFinder() {
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [country, setCountry] = useState(null);
  const [currency, setCurrency] = useState(null);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Highest });
      setLocation(location);

      const { latitude, longitude } = location.coords;
      const apiKey = '475c38febe7b413bba4ba4b654d7edc2';
      const url = `https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=${apiKey}`;

      try {
        const response = await axios.get(url);
        if (response.data.results.length > 0) {
          const components = response.data.results[0].components;
          const countryComponent = components.country;
          const currencyComponent = response.data.results[0].annotations.currency;
          // update into country and currency
          setCountry(countryComponent); 
          setCurrency(currencyComponent ? `${currencyComponent.iso_code} (${currencyComponent.name})` : 'Currency not found');
        } else {
          setErrorMsg('No results found');
        }
      } catch (error) {
        console.error('Error fetching location:', error);
        setErrorMsg('Error fetching location');
      }
    })();
  }, []);

  let text = 'Waiting..';
  if (errorMsg) {
    text = errorMsg;
  } else if (country && currency) {
    text = `You are in ${country} and the currency used is ${currency}`;
  } else if (country) {
    text = `You are in ${country}, fetching currency...`;
  } else if (location) {
    text = JSON.stringify(location);
  }

  return (
    <LinearGradient colors={['#a0e5f0', '#f0d0d7']} style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.paragraph}>{text}</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: 'transparent',
  },
  paragraph: {
    fontSize: 18,
    textAlign: 'center',
    color: '#333',
  },
});
